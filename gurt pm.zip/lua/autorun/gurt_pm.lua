player_manager.AddValidModel( "gurt", "models/gurt/gurt/gurt_pm.mdl" )
list.Set( "PlayerOptionsModel", "gurt", "models/gurt/gurt/gurt_pm.mdl" )
//player_manager.AddValidHands( "gurt", "models/gurt/gurt/gurt_pm_arms", 0, "00000000" )